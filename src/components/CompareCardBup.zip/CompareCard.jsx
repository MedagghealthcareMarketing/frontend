import React from "react";
import Styles from "../components/CompareCard.module.css";

export const CompareCard = ({ data }) => {
  return (
    <div>
      <div className={`row mt-5 mb-5 ${Styles.CardRow}`}>
        {data.map((item, index) => (
          <div
            className={`col-12 col-sm-12 col-md-6 col-lg-4 col-xl-4 col-xxl-4 ${Styles.CardCol}`}
            key={index}
          >
            <div className={`card  border-0 p-0 ${Styles.Card}`}>
              <div className={`row ${Styles.Row}`}>
                <div className={`col-4 p-0 ${Styles.ColLeft}`}>
                  <img
                    src={item.CardImg}
                    alt={item.title}
                    className={`card-img img-fluid ${Styles.CardImage}`}
                  />
                </div>
                <div className={`col-8 p-0 ${Styles.ColRight}`}>
                  <div className={`card-body pt-4  ${Styles.CardBody}`}>
                    <h3
                      className={`card-title text-start mt-1 ${Styles.CardTitle}`}
                    >
                      {item.CardTitle}
                    </h3>
                    <p className={`card-text text-start ${Styles.CardText}`}>
                      {item.CardText}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
