import React, { useState } from "react";
import faqData from "../json/FAQdata"; // Importing the FAQ data
import Styles from "../components/FAQAccordion.module.css"; // Importing custom styles

const FAQAccordion = () => {
  const itemsPerSection = 5; // Number of FAQs per section
  const numSections = Math.ceil(faqData.length / itemsPerSection); // Calculate the number of sections needed

  const [activeSection, setActiveSection] = useState(0); // Track the active section

  // Generate section buttons dynamically
  const sectionButtons = [...Array(numSections).keys()].map((sectionIndex) => (
    <button
      key={sectionIndex}
      onClick={() => setActiveSection(sectionIndex)}
      className={`btn mx-2`}
      style={{ backgroundColor: '#E9296A', color: 'white' }} // Apply custom background color
    >
      Section {sectionIndex + 1}
    </button>
  ));

  // Generate the FAQ items for the current section
  const currentFAQs = faqData.slice(
    activeSection * itemsPerSection,
    (activeSection + 1) * itemsPerSection
  );

  return (
    <div className="container">
      <div className="d-flex justify-content-center my-3">{sectionButtons}</div>

      <div className="accordion p-3" id="faqAccordion">
          {currentFAQs.map((item) => (
            <div key={item.id} className="accordion-item">
              <h2 className={`accordion-header ${Styles.AccordionHeader}`} id={`heading${item.id}`} >
                <button
                  className={`accordion-button ${Styles.AccordionBtn}`}
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target={`#collapse${item.id}`}
                  aria-expanded="true"
                  aria-controls={`collapse${item.id}`}
                  style={{backgroundColor:"white"}}
                >
                  {item.question}
                </button>
              </h2>
              <div
                id={`collapse${item.id}`}
                className="accordion-collapse collapse"
                aria-labelledby={`heading${item.id}`}
                data-bs-parent="#faqAccordion"
              >
                <div className="accordion-body" dangerouslySetInnerHTML={{ __html: item.answer }} />
              </div>
            </div>
          ))}
      </div>
    </div>
  );
};

export default FAQAccordion;
